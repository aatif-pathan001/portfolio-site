/**
 * Portfolio JS — Aatif Khan Pathan
 * Particle Field, Scroll Animations, Nav, Filtering, Contact Form
 */

// ═══════════════════════════════════════════════════════
// 1. PARTICLE FIELD ENGINE
// ═══════════════════════════════════════════════════════
class ParticleEngine {
  constructor(canvasId) {
    this.canvas  = document.getElementById(canvasId);
    this.ctx     = this.canvas.getContext('2d');
    this.particles  = [];
    this.mouse      = { x: -9999, y: -9999 };
    this.frameId    = null;
    this.config = {
      count:          120,
      maxRadius:      1.8,
      minRadius:      0.4,
      speed:          0.25,
      connectDist:    110,
      mouseRadius:    160,
      baseOpacity:    0.55,
      starColor:      '0, 229, 255',
      nodeColor:      '124, 58, 237',
      lineOpacity:    0.12,
    };
    this._bind();
    this._resize();
    this._init();
    this._loop();
  }

  _bind() {
    window.addEventListener('resize', () => this._resize());
    window.addEventListener('mousemove', (e) => {
      this.mouse.x = e.clientX;
      this.mouse.y = e.clientY;
    });
    window.addEventListener('mouseleave', () => {
      this.mouse.x = -9999;
      this.mouse.y = -9999;
    });
  }

  _resize() {
    this.canvas.width  = window.innerWidth;
    this.canvas.height = window.innerHeight;
  }

  _init() {
    this.particles = [];
    const { count, maxRadius, minRadius, speed } = this.config;
    const W = this.canvas.width;
    const H = this.canvas.height;

    for (let i = 0; i < count; i++) {
      const isStar = Math.random() > 0.25; // 75% tiny stars, 25% network nodes
      this.particles.push({
        x:  Math.random() * W,
        y:  Math.random() * H,
        vx: (Math.random() - 0.5) * speed,
        vy: (Math.random() - 0.5) * speed,
        r:  isStar
            ? Math.random() * 0.8 + 0.2
            : Math.random() * (maxRadius - minRadius) + minRadius,
        opacity:    Math.random() * 0.5 + 0.2,
        twinkle:    Math.random() * Math.PI * 2, // phase offset
        twinkleSpeed: Math.random() * 0.03 + 0.01,
        isStar,
        pulse:  0,
      });
    }
  }

  _loop() {
    this._draw();
    this.frameId = requestAnimationFrame(() => this._loop());
  }

  _draw() {
    const { ctx, canvas, particles, mouse, config } = this;
    const { connectDist, mouseRadius, lineOpacity, starColor, nodeColor } = config;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Update & draw particles
    for (let p of particles) {
      // Move
      p.x += p.vx;
      p.y += p.vy;
      p.twinkle += p.twinkleSpeed;

      // Wrap edges
      if (p.x < 0) p.x = canvas.width;
      if (p.x > canvas.width)  p.x = 0;
      if (p.y < 0) p.y = canvas.height;
      if (p.y > canvas.height) p.y = 0;

      // Mouse repulsion for nodes
      if (!p.isStar) {
        const dx = p.x - mouse.x;
        const dy = p.y - mouse.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < mouseRadius) {
          const force = (mouseRadius - dist) / mouseRadius;
          p.vx += (dx / dist) * force * 0.04;
          p.vy += (dy / dist) * force * 0.04;
          // Dampen velocity
          p.vx *= 0.96;
          p.vy *= 0.96;
        }
      }

      // Twinkle opacity
      const twinkledOpacity = p.opacity * (0.6 + 0.4 * Math.sin(p.twinkle));

      // Draw
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      if (p.isStar) {
        ctx.fillStyle = `rgba(${starColor}, ${twinkledOpacity})`;
      } else {
        ctx.fillStyle = `rgba(${nodeColor}, ${twinkledOpacity * 1.4})`;
        // Soft glow for nodes
        const grd = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4);
        grd.addColorStop(0, `rgba(${nodeColor}, 0.15)`);
        grd.addColorStop(1, `rgba(${nodeColor}, 0)`);
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${nodeColor}, ${twinkledOpacity})`;
      }
      ctx.fill();
    }

    // Draw connections between nearby nodes (non-star particles)
    const nodes = particles.filter(p => !p.isStar);
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < connectDist) {
          const alpha = lineOpacity * (1 - dist / connectDist);
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.strokeStyle = `rgba(0, 229, 255, ${alpha})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }
  }

  destroy() {
    cancelAnimationFrame(this.frameId);
    window.removeEventListener('resize', this._resize);
  }
}

// ═══════════════════════════════════════════════════════
// 2. NAVIGATION
// ═══════════════════════════════════════════════════════
class Navigation {
  constructor() {
    this.nav     = document.querySelector('.nav');
    this.burger  = document.querySelector('.nav-hamburger');
    this.links   = document.querySelector('.nav-links');
    this._bind();
    this._onScroll();
  }

  _bind() {
    window.addEventListener('scroll', () => this._onScroll());
    this.burger?.addEventListener('click', () => this._toggle());

    // Close menu on link click
    this.links?.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        this.links.classList.remove('open');
      });
    });
  }

  _onScroll() {
    if (window.scrollY > 60) {
      this.nav.classList.add('scrolled');
    } else {
      this.nav.classList.remove('scrolled');
    }
  }

  _toggle() {
    this.links.classList.toggle('open');
  }
}

// ═══════════════════════════════════════════════════════
// 3. SCROLL REVEAL
// ═══════════════════════════════════════════════════════
class ScrollReveal {
  constructor() {
    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, i) => {
          if (entry.isIntersecting) {
            // Stagger delay for children in a group
            const delay = entry.target.dataset.delay || 0;
            setTimeout(() => {
              entry.target.classList.add('visible');
            }, delay);
            this.observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -50px 0px' }
    );

    this._observe();
  }

  _observe() {
    // Generic reveals
    document.querySelectorAll('.reveal').forEach(el => this.observer.observe(el));

    // Timeline items with staggered delay
    document.querySelectorAll('.timeline-item').forEach((el, i) => {
      el.dataset.delay = i * 150;
      this.observer.observe(el);
    });

    // Tech categories
    document.querySelectorAll('.tech-category').forEach((el, i) => {
      el.dataset.delay = i * 80;
      this.observer.observe(el);
    });

    // Project cards
    document.querySelectorAll('.project-card').forEach((el, i) => {
      el.dataset.delay = i * 60;
      this.observer.observe(el);
    });
  }
}

// ═══════════════════════════════════════════════════════
// 4. PROJECT FILTER
// ═══════════════════════════════════════════════════════
class ProjectFilter {
  constructor() {
    this.filterBtns = document.querySelectorAll('.filter-btn');
    this.cards      = document.querySelectorAll('.project-card');
    this.active     = 'all';
    this._bind();
  }

  _bind() {
    this.filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        this.filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.active = btn.dataset.filter;
        this._filter();
      });
    });
  }

  _filter() {
    this.cards.forEach((card, i) => {
      const cat = card.dataset.category;
      const show = this.active === 'all' || cat === this.active;
      if (show) {
        card.style.display = '';
        setTimeout(() => {
          card.style.opacity    = '1';
          card.style.transform  = 'translateY(0)';
        }, i * 40);
      } else {
        card.style.opacity   = '0';
        card.style.transform = 'translateY(20px)';
        setTimeout(() => { card.style.display = 'none'; }, 300);
      }
    });
  }
}

// ═══════════════════════════════════════════════════════
// 5. CONTACT FORM
// ═══════════════════════════════════════════════════════
class ContactForm {
  constructor() {
    this.form    = document.getElementById('contact-form');
    this.message = document.getElementById('form-message');
    if (this.form) this._bind();
  }

  _bind() {
    this.form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = this.form.querySelector('.form-submit');
      btn.textContent = 'Sending…';
      btn.disabled = true;

      const data = {
        name:    this.form.querySelector('[name="name"]').value,
        email:   this.form.querySelector('[name="email"]').value,
        subject: this.form.querySelector('[name="subject"]').value,
        message: this.form.querySelector('[name="message"]').value,
      };

      try {
        const res = await fetch('/api/contact', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        });
        const json = await res.json();
        if (res.ok) {
          this._showMessage(json.message || 'Message sent! I\'ll reply soon.', 'success');
          this.form.reset();
        } else {
          this._showMessage(json.detail || 'Something went wrong. Try again.', 'error');
        }
      } catch {
        this._showMessage('Network error. Please email me directly.', 'error');
      } finally {
        btn.textContent = 'Send Message';
        btn.disabled = false;
      }
    });
  }

  _showMessage(text, type) {
    this.message.textContent = text;
    this.message.className = `form-message ${type}`;
    setTimeout(() => { this.message.className = 'form-message'; }, 6000);
  }
}

// ═══════════════════════════════════════════════════════
// 6. CURSOR GLOW
// ═══════════════════════════════════════════════════════
class CursorGlow {
  constructor() {
    this.el = document.querySelector('.cursor-glow');
    if (!this.el) return;
    window.addEventListener('mousemove', (e) => {
      this.el.style.left = e.clientX + 'px';
      this.el.style.top  = e.clientY + 'px';
    });
  }
}

// ═══════════════════════════════════════════════════════
// 7. SMOOTH SCROLL COUNT-UP for Stats
// ═══════════════════════════════════════════════════════
class StatCountUp {
  constructor() {
    this.stats = document.querySelectorAll('.stat-value');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          this._animateStat(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });
    this.stats.forEach(s => observer.observe(s));
  }

  _animateStat(el) {
    const final = el.textContent;
    const numMatch = final.match(/[\d.]+/);
    if (!numMatch) return;
    const num = parseFloat(numMatch[0]);
    const suffix = final.replace(numMatch[0], '');
    const duration = 1400;
    const startTime = performance.now();

    const animate = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = (num * eased).toFixed(num % 1 !== 0 ? 2 : 0);
      el.textContent = current + suffix;
      if (progress < 1) requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);
  }
}

// ═══════════════════════════════════════════════════════
// 8. INIT
// ═══════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  new ParticleEngine('particle-canvas');
  new Navigation();
  new ScrollReveal();
  new ProjectFilter();
  new ContactForm();
  new CursorGlow();
  new StatCountUp();
});
