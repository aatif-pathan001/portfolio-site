"""
Components Module
=================
Each function returns an HTML string for a section of the portfolio.
Keeps main app.py clean and sections independently editable.
"""

from data.portfolio_data import (
    PERSONAL, STATS, TECH_STACK, EXPERIENCE, PROJECTS
)


# ── Utility helpers ────────────────────────────────────────────────────────────
def _tag(tag: str, content: str, **attrs) -> str:
    attr_str = " ".join(
        f'{k.replace("_", "-")}="{v}"' for k, v in attrs.items() if v
    )
    return f"<{tag} {attr_str}>{content}</{tag}>" if attr_str else f"<{tag}>{content}</{tag}>"


def _tags(content: str, classes: str = "", **kwargs) -> str:
    return _tag("span", content, class_=classes, **kwargs)


# ── SVG Icons ──────────────────────────────────────────────────────────────────
ICONS = {
    "github":   '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/></svg>',
    "external": '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3"/></svg>',
    "mail":     '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
    "linkedin": '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
    "twitter":  '<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>',
    "blog":     '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>',
    "phone":    '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81 19.79 19.79 0 01.01 1.19 2 2 0 012 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 7.91a16 16 0 006.18 6.18l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/></svg>',
    "location": '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>',
    "download": '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    "arrow":    '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
}


# ── NAV ────────────────────────────────────────────────────────────────────────
def render_nav() -> str:
    links = [
        ("About",    "#hero"),
        ("Journey",  "#journey"),
        ("Stack",    "#stack"),
        ("Projects", "#projects"),
        ("Contact",  "#contact"),
    ]
    link_items = "".join(
        f'<li><a href="{href}">{label}</a></li>' for label, href in links
    )
    return f"""
<nav class="nav">
  <a class="nav-brand" href="#hero">
    <span>aatif</span>.ml
  </a>
  <ul class="nav-links">
    {link_items}
    <li><a href="{PERSONAL['blog']}" class="blog-link" target="_blank" rel="noopener">Blog {ICONS['external']}</a></li>
  </ul>
  <div class="nav-hamburger" id="hamburger" aria-label="Toggle menu">
    <span></span><span></span><span></span>
  </div>
</nav>"""


# ── HERO ───────────────────────────────────────────────────────────────────────
def render_hero() -> str:
    stats_html = "".join(f"""
    <div class="stat-item">
      <span class="stat-value">{s['value']}</span>
      <span class="stat-label">{s['label']}</span>
    </div>""" for s in STATS)

    return f"""
<section id="hero">
  <div class="hero-status">
    <span class="hero-status-dot"></span>
    {PERSONAL['status']}
  </div>

  <h1 class="hero-headline">
    Building the<br>
    <span class="gradient-text">Intelligence</span><br>
    of Tomorrow.
  </h1>

  <p class="hero-sub">
    <span class="highlight">ML Engineer @ TCS</span> · Electrical Engineering roots, AI/Deep Learning focus.<br>
    Specialist in <span class="highlight">PyTorch</span>, <span class="highlight">YOLO</span>,
    <span class="highlight">BERT</span>, and production-grade <span class="highlight">MLOps</span>.
  </p>

  <div class="hero-ctas">
    <a href="#projects" class="btn btn-primary">
      {ICONS['arrow']} View My Projects
    </a>
    <a href="{PERSONAL['resume_url']}" download class="btn btn-outline">
      {ICONS['download']} Download Resume
    </a>
  </div>

  <div class="stats-grid">
    {stats_html}
  </div>
</section>"""


# ── JOURNEY ────────────────────────────────────────────────────────────────────
def render_journey() -> str:
    badge_map = {
        "current":   ("badge-current", "● Live"),
        "past":      ("badge-past",    "Past"),
        "education": ("badge-education", "Education"),
    }

    items_html = ""
    for exp in EXPERIENCE:
        badge_cls, badge_label = badge_map.get(exp["status"], ("", ""))
        is_current_cls = "current" if exp["status"] == "current" else exp["status"]
        highlights = "".join(f"<li>{h}</li>" for h in exp["highlights"])
        items_html += f"""
    <div class="timeline-item {is_current_cls}">
      <div class="timeline-dot"></div>
      <div class="timeline-meta">
        <span class="timeline-period">{exp['period']}</span>
        <span class="timeline-badge {badge_cls}">{badge_label}</span>
      </div>
      <div class="timeline-role">{exp['role']}</div>
      <div class="timeline-company">{exp['company']} · {exp['location']}</div>
      <ul class="timeline-highlights">{highlights}</ul>
    </div>"""

    return f"""
<section id="journey">
  <div class="reveal">
    <div class="section-label">Career Roadmap</div>
    <h2 class="section-title">The Journey</h2>
    <p class="section-sub">From Electrical Engineering to production ML systems.</p>
  </div>
  <div class="timeline">{items_html}</div>
</section>"""


# ── TECH STACK ─────────────────────────────────────────────────────────────────
def render_stack() -> str:
    cats_html = ""
    for cat_name, techs in TECH_STACK.items():
        tags = "".join(f'<span class="tech-tag">{t}</span>' for t in techs)
        cats_html += f"""
    <div class="tech-category">
      <div class="tech-cat-name">{cat_name}</div>
      <div class="tech-tags">{tags}</div>
    </div>"""

    return f"""
<section id="stack">
  <div class="reveal">
    <div class="section-label">Tools of the Trade</div>
    <h2 class="section-title">Tech Stack</h2>
    <p class="section-sub">Technologies I use to build, train, and ship ML systems.</p>
  </div>
  <div class="tech-grid">{cats_html}</div>
</section>"""


# ── PROJECTS ───────────────────────────────────────────────────────────────────
def render_projects() -> str:
    # Collect unique categories
    categories = sorted(set(p["category"] for p in PROJECTS))
    filter_btns = '<button class="filter-btn active" data-filter="all">All</button>'
    filter_btns += "".join(
        f'<button class="filter-btn" data-filter="{c}">{c}</button>'
        for c in categories
    )

    cards_html = ""
    for proj in PROJECTS:
        tags    = "".join(f'<span class="project-tag">{t}</span>' for t in proj["tags"])
        metrics = "".join(f'<span class="metric-tag">{m}</span>' for m in proj["metrics"])
        featured_badge = '<span class="featured-badge">Featured</span>' if proj["featured"] else ""
        card_cls = "project-card featured" if proj["featured"] else "project-card"
        cards_html += f"""
    <div class="{card_cls}" data-category="{proj['category']}">
      <div class="project-header">
        <span class="project-category">{proj['category']}</span>
        {featured_badge}
      </div>
      <div class="project-title">{proj['title']}</div>
      <p class="project-desc">{proj['description']}</p>
      <div class="project-metrics">{metrics}</div>
      <div class="project-tags">{tags}</div>
      <div class="project-actions">
        <a href="{proj['github']}" class="btn-icon" target="_blank">
          {ICONS['github']} GitHub
        </a>
        <a href="{proj['demo']}" class="btn-icon" target="_blank">
          {ICONS['external']} Live Demo
        </a>
      </div>
    </div>"""

    return f"""
<section id="projects">
  <div class="reveal">
    <div class="section-label">Portfolio</div>
    <h2 class="section-title">Projects</h2>
    <p class="section-sub">10 production ML systems and more — all with real metrics.</p>
  </div>
  <div class="projects-filter">{filter_btns}</div>
  <div class="projects-grid">{cards_html}</div>
</section>"""


# ── CONTACT ────────────────────────────────────────────────────────────────────
def render_contact() -> str:
    contact_items = [
        ("email",    ICONS["mail"],     PERSONAL["email"],    f'mailto:{PERSONAL["email"]}'),
        ("linkedin", ICONS["linkedin"], "linkedin.com/in/aatif-khan-pathan", PERSONAL["linkedin"]),
        ("github",   ICONS["github"],   "github.com/aatifkhan",              PERSONAL["github"]),
        ("blog",     ICONS["blog"],     "Blog & Articles",                    PERSONAL["blog"]),
        ("location", ICONS["location"], PERSONAL["location"],                 "#"),
    ]
    links_html = "".join(f"""
    <a href="{url}" class="contact-link" target="_blank" rel="noopener">
      <span class="contact-link-icon">{icon}</span>
      {label}
    </a>""" for _, icon, label, url in contact_items)

    return f"""
<section id="contact">
  <div class="contact-grid">
    <div class="contact-info reveal">
      <h3>Let's Build<br>Something <span style="color:var(--accent-cyan)">Intelligent</span>.</h3>
      <p>Open to senior ML / AI Engineering roles, research collaborations, and freelance model-building engagements. Drop a message — I read everything.</p>
      <div class="contact-links">{links_html}</div>
    </div>

    <div class="reveal">
      <form class="contact-form" id="contact-form" novalidate>
        <div class="form-group">
          <label class="form-label" for="name">Name</label>
          <input class="form-input" type="text" id="name" name="name" placeholder="Your name" required>
        </div>
        <div class="form-group">
          <label class="form-label" for="email">Email</label>
          <input class="form-input" type="email" id="email" name="email" placeholder="your@email.com" required>
        </div>
        <div class="form-group">
          <label class="form-label" for="subject">Subject</label>
          <input class="form-input" type="text" id="subject" name="subject" placeholder="What's this about?">
        </div>
        <div class="form-group">
          <label class="form-label" for="message">Message</label>
          <textarea class="form-textarea" id="message" name="message" placeholder="Tell me about the project or opportunity…" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary form-submit">
          {ICONS['arrow']} Send Message
        </button>
        <div class="form-message" id="form-message"></div>
      </form>
    </div>
  </div>
</section>"""


# ── FOOTER ─────────────────────────────────────────────────────────────────────
def render_footer() -> str:
    return f"""
<footer>
  <div class="footer-copy">
    © 2025 <span>{PERSONAL['name']}</span>. Built with Python + FastAPI + pure CSS.
  </div>
  <div class="footer-links">
    <a href="{PERSONAL['github']}" target="_blank">GitHub</a>
    <a href="{PERSONAL['linkedin']}" target="_blank">LinkedIn</a>
    <a href="{PERSONAL['blog']}" target="_blank">Blog</a>
    <a href="{PERSONAL['resume_url']}" download>Resume</a>
  </div>
</footer>"""


# ── FULL PAGE ──────────────────────────────────────────────────────────────────
def render_page() -> str:
    """Assemble and return the complete HTML page."""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="{PERSONAL['name']} — {PERSONAL['title']}. {PERSONAL['summary'][:160]}">
  <meta name="author" content="{PERSONAL['name']}">
  <meta property="og:title" content="{PERSONAL['name']} | {PERSONAL['title']}">
  <meta property="og:description" content="{PERSONAL['tagline']}">
  <meta property="og:type" content="website">
  <title>{PERSONAL['name']} | ML Engineer</title>
  <link rel="stylesheet" href="/static/css/style.css">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>⚡</text></svg>">
</head>
<body>

<!-- Background layers -->
<canvas id="particle-canvas"></canvas>
<div class="noise-overlay"></div>
<div class="cursor-glow"></div>

<div class="page-wrapper">
  {render_nav()}

  <main>
    {render_hero()}

    <div class="section-divider"></div>

    {render_journey()}

    <div class="section-divider"></div>

    {render_stack()}

    <div class="section-divider"></div>

    {render_projects()}

    <div class="section-divider"></div>

    {render_contact()}
  </main>

  {render_footer()}
</div>

<script src="/static/js/main.js" defer></script>
</body>
</html>"""
